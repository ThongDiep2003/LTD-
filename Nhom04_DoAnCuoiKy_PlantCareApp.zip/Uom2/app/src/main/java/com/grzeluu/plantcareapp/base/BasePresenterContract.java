package com.grzeluu.plantcareapp.base;

public interface BasePresenterContract {
}
