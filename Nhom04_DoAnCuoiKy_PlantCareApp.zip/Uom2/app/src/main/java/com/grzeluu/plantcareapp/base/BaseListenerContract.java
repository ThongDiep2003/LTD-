package com.grzeluu.plantcareapp.base;

public interface BaseListenerContract {
    void onStart();
    void onEnd();
}
